package com.postpony.model;

public enum LabelSize
{
    S4X6,


    S8X11,
}