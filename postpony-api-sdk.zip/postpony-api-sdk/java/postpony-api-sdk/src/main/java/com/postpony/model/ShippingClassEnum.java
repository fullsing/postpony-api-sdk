package com.postpony.model;

public enum ShippingClassEnum {
    Fedex,

    Usps,

    Ups,

    Dhl
}
