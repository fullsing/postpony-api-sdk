package com.postpony.model;

public enum ElectronicExportType {

    NoEEISED,

    PreDepartureITN,
}
